<?php

return [

    // The alias Underscore will be mapped to
    'alias' => 'Underscore',

    // Various aliases for methods, you can specify your own
    'aliases' => [
        'contains' => 'find',
        'getLast' => 'last',
        'select' => 'filter',
        'sortBy' => 'sort',
    ],

];
